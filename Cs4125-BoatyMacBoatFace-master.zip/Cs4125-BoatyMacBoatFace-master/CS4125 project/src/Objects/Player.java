package Objects;

public class Player extends appUsers
{
    public Player()
    {
    
    }
    public Player(String name, String uName, String password)
    {
        setName(name);
        setUsername(uName);
        setPassword(password);
    }
    

}   
