package Application;
import UIpackage.loginUI;

public class ApplicationMain
{
    public static void main (String [] args)
    {
        loginUI login = new loginUI();
        login.login();
    }
}
