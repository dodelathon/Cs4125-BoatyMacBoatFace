package UIpackage;
interface UI 
{

    public String getUname();
    public String getPassword();
    public void setPassword(String password);
    
}
